import { adminDb, hasAdminCredentials, isPermissionDeniedError, markAdminCredentialsUnavailable } from './adminFirebase';

export interface ProjectOwnershipResult {
  allowed: boolean;
  status?: number;
  error?: string;
  projectData?: Record<string, any>;
}

const MAX_TRACKED_PROJECTS = 10_000;
const inMemoryProjectOwners = new Map<string, string>();
const inMemoryProjectSnapshots = new Map<string, Record<string, any>>();

export function registerProjectOwner(
  projectId: string,
  ownerId: string,
  projectData?: Record<string, any>
): void {
  if (!projectId || !ownerId) return;
  if (!inMemoryProjectOwners.has(projectId) && inMemoryProjectOwners.size >= MAX_TRACKED_PROJECTS) {
    const oldest = inMemoryProjectOwners.keys().next().value;
    if (oldest) {
      inMemoryProjectOwners.delete(oldest);
      inMemoryProjectSnapshots.delete(oldest);
    }
  }
  inMemoryProjectOwners.set(projectId, ownerId);
  if (projectData) {
    inMemoryProjectSnapshots.set(projectId, projectData);
  }
}

export function getRegisteredProjectOwner(projectId: string): string | undefined {
  return inMemoryProjectOwners.get(projectId);
}

export function resetProjectOwnersForTests(): void {
  inMemoryProjectOwners.clear();
  inMemoryProjectSnapshots.clear();
}

/**
 * Verifies server-side project ownership using Firebase Admin (`adminDb`) when configured,
 * with a fallback to the authoritative server session ownership map when running without
 * Firebase Admin credentials. Never uses the unauthenticated client Firebase Web SDK on the server.
 */
export async function verifyProjectOwnership(
  projectId: string,
  userId: string,
  options: { requirePersisted?: boolean; claimIfUnowned?: boolean } = {}
): Promise<ProjectOwnershipResult> {
  if (!projectId || typeof projectId !== 'string') {
    return { allowed: false, status: 400, error: 'A valid projectId is required.' };
  }
  if (!userId || typeof userId !== 'string') {
    return { allowed: false, status: 401, error: 'Authentication is required.' };
  }

  // 1. Check authoritative in-memory ownership map first for fast cross-tenant isolation
  const existingOwner = inMemoryProjectOwners.get(projectId);
  if (existingOwner && existingOwner !== userId) {
    return {
      allowed: false,
      status: 403,
      error: 'Unauthorized: You do not own this project workspace.'
    };
  }

  // 2. Query Firebase Admin Firestore when credentials are available
  if (hasAdminCredentials()) {
    try {
      const snap = await adminDb.collection('projects').doc(projectId).get();
      if (snap.exists) {
        const data = snap.data() || {};
        if (data.ownerId && data.ownerId !== userId) {
          registerProjectOwner(projectId, data.ownerId, data);
          return {
            allowed: false,
            status: 403,
            error: 'Unauthorized: You do not own this project workspace.'
          };
        }
        registerProjectOwner(projectId, data.ownerId || userId, data);
        return { allowed: true, projectData: data };
      }

      if (options.requirePersisted && !inMemoryProjectSnapshots.has(projectId)) {
        return {
          allowed: false,
          status: 404,
          error: 'Save this workspace to your account before running server commands.'
        };
      }
    } catch (error: any) {
      if (isPermissionDeniedError(error)) {
        markAdminCredentialsUnavailable(error);
      } else {
        return {
          allowed: false,
          status: 503,
          error: 'Could not verify project ownership. Retry when project storage is available.'
        };
      }
    }
  } else if (options.requirePersisted && !inMemoryProjectSnapshots.has(projectId) && !existingOwner) {
    return {
      allowed: false,
      status: 404,
      error: 'Save this workspace to your account before running server commands.'
    };
  }

  if (options.claimIfUnowned !== false && !existingOwner) {
    registerProjectOwner(projectId, userId);
  }

  return {
    allowed: true,
    projectData: inMemoryProjectSnapshots.get(projectId)
  };
}
