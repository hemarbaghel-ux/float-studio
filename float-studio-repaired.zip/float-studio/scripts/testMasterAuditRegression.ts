import assert from 'node:assert/strict';
import {
  verifyProjectOwnership,
  registerProjectOwner,
  resetProjectOwnersForTests
} from '../src/server/projectOwnership';
import { ModelRouter } from '../src/server/providers/router';
import { OpenAIAdapter } from '../src/server/providers/openai';
import { DASHBOARD_MODELS } from '../src/features/dashboard/dashboardModels';
import { INITIAL_MODELS, FLOAT_BASIC_MODEL } from '../src/features/ai/registry';
import { useAIStore } from '../src/store/aiStore';
import { useIDEStore } from '../src/store/index';
import { ToolRegistry } from '../src/server/agent/toolRegistry';
import { ProposalService } from '../src/server/agent/proposalService';
import {
  getUserSubscription,
  updateUserSubscription,
  resetSubscriptionMemoryState
} from '../src/server/subscription/subscriptionPersistence';

let passed = 0;
let failed = 0;

function check(condition: boolean, name: string) {
  if (condition) {
    console.log(`[PASS] ${name}`);
    passed++;
  } else {
    console.error(`[FAIL] ${name}`);
    failed++;
  }
}

async function runMasterAuditRegressionTests() {
  console.log('=== FLOAT AI — MASTER AUDIT & REGRESSION TEST SUITE ===\n');

  // 1. Server-side Project Ownership & Cross-Tenant Isolation
  console.log('--- 1. Server-Side Project Ownership & Tenant Isolation ---');
  resetProjectOwnersForTests();

  const aliceClaim = await verifyProjectOwnership('proj-alice-1', 'user-alice');
  check(aliceClaim.allowed === true, 'Owner (user-alice) is permitted to access newly created project');

  const bobIntrusion = await verifyProjectOwnership('proj-alice-1', 'user-bob');
  check(bobIntrusion.allowed === false && bobIntrusion.status === 403, 'Second user (user-bob) is blocked with HTTP 403 from accessing user-alice project');

  const unpersistedExec = await verifyProjectOwnership('proj-never-saved', 'user-alice', {
    requirePersisted: true,
    claimIfUnowned: false
  });
  check(unpersistedExec.allowed === false && unpersistedExec.status === 404, 'Unpersisted project returns 404 when requirePersisted is true');

  registerProjectOwner('proj-saved-cloud', 'user-alice', {
    ownerId: 'user-alice',
    name: 'Cloud Project',
    files: JSON.stringify([{ path: 'src/app.ts', content: 'export const x = 1;' }])
  });
  const aliceSaved = await verifyProjectOwnership('proj-saved-cloud', 'user-alice', { requirePersisted: true });
  check(aliceSaved.allowed === true && Boolean(aliceSaved.projectData), 'Persisted project resolves projectData for owner');

  // 2. Model Catalog, Router & AI Store Selection Preservation
  console.log('\n--- 2. Model Catalog, Router & AI Store Selection Integrity ---');
  const router = new ModelRouter();
  check(DASHBOARD_MODELS.length === 10, 'DASHBOARD_MODELS has all 10 verified models');
  check(Boolean(FLOAT_BASIC_MODEL && FLOAT_BASIC_MODEL.id === 'float-basic'), 'FLOAT_BASIC_MODEL is exported and defined');
  check(INITIAL_MODELS.some(m => m.id === 'gpt-6-astra') && INITIAL_MODELS.some(m => m.id === 'gpt-6.1-sol'), 'Preview cloud agent models are present in INITIAL_MODELS');

  for (const modelId of ['gpt-4o', 'o3-mini', 'gpt-4o-mini', 'o1', 'o1-mini', 'gpt-4.5-preview', 'float-basic', 'gpt-6-astra', 'gpt-6.1-sol']) {
    useAIStore.getState().setSelectedModel(modelId);
    check(useAIStore.getState().selectedModel === modelId, `useAIStore preserves selectedModel="${modelId}" without silent overwrite`);
    const resolved = router.resolveRoute(modelId);
    check(resolved.route.provider === 'openai', `ModelRouter routes "${modelId}" to OpenAI provider`);
  }

  // 3. OpenAIAdapter Exact Model Preservation
  console.log('\n--- 3. OpenAIAdapter Upstream Model ID Preservation ---');
  const adapter = new OpenAIAdapter();
  check((adapter as any).resolveApiModel('o1') === 'o1', 'OpenAIAdapter preserves o1 model ID');
  check((adapter as any).resolveApiModel('o3-mini') === 'o3-mini', 'OpenAIAdapter preserves o3-mini model ID');
  check((adapter as any).resolveApiModel('gpt-4o-mini') === 'gpt-4o-mini', 'OpenAIAdapter preserves gpt-4o-mini model ID');
  check((adapter as any).resolveApiModel('float-basic') === 'gpt-4o-mini', 'OpenAIAdapter maps float-basic to gpt-4o-mini');

  // 4. IDE Store File Lifecycle (Create, Update, Rename, Delete)
  console.log('\n--- 4. IDE Store File Lifecycle & Rename Safety ---');
  useIDEStore.getState().clearProject();
  const fileId = 'test-file-rename-1';
  useIDEStore.getState().addFile(null, {
    id: fileId,
    name: 'utils.ts',
    type: 'file',
    content: 'export const util = () => true;\n'
  });
  check(useIDEStore.getState().files.some(f => f.id === fileId && f.name === 'utils.ts'), 'addFile adds utils.ts to workspace');
  check(useIDEStore.getState().activeFileId === fileId, 'addFile opens and activates new file');

  useIDEStore.getState().renameFile(fileId, '../evil.ts');
  check(useIDEStore.getState().files.some(f => f.id === fileId && f.name === 'utils.ts'), 'renameFile rejects path traversal names');

  useIDEStore.getState().renameFile(fileId, 'helpers.ts');
  check(useIDEStore.getState().files.some(f => f.id === fileId && f.name === 'helpers.ts'), 'renameFile updates file name to helpers.ts');
  check(useIDEStore.getState().openTabs.some(t => t.fileId === fileId), 'renameFile preserves open editor tab');

  useIDEStore.getState().deleteFile(fileId);
  check(!useIDEStore.getState().files.some(f => f.id === fileId), 'deleteFile removes file from workspace');
  check(!useIDEStore.getState().openTabs.some(t => t.fileId === fileId), 'deleteFile closes associated editor tab');

  // 5. Subscription Persistence Memory Reset Fix
  console.log('\n--- 5. Subscription Persistence State Reset ---');
  resetSubscriptionMemoryState();
  const sub = await getUserSubscription('user-sub-test');
  await updateUserSubscription({ ...sub, planId: 'pro' });
  const updatedSub = await getUserSubscription('user-sub-test');
  check(updatedSub.planId === 'pro', 'Subscription update persisted in memory');
  resetSubscriptionMemoryState();
  const resetSub = await getUserSubscription('user-sub-test');
  check(resetSub.planId === 'free', 'resetSubscriptionMemoryState clears memorySubscriptions map properly');

  // 6. Agent Tool Security & Proposal Immutability
  console.log('\n--- 6. Agent Tool Security & Proposal Workflow ---');
  const vFiles = new Map<string, { path: string; name?: string; content?: string; type: string }>();
  vFiles.set('src/index.ts', { path: 'src/index.ts', name: 'index.ts', content: 'export const v = 1;\n', type: 'file' });
  vFiles.set('.env', { path: '.env', name: '.env', content: 'OPENAI_API_KEY=secret', type: 'file' });

  const ctx = { userId: 'user-sec', projectId: 'proj-sec', projectName: 'SecTest', virtualFiles: vFiles };
  const secretRead = await ToolRegistry.execute('read_file', { path: '.env' }, ctx);
  check(!secretRead.success, 'ToolRegistry blocks reading .env file');

  const propRes = await ProposalService.createProposalDurable({
    ownerId: 'user-sec',
    projectId: 'proj-sec',
    description: 'Update v to 2',
    rawChanges: [{ path: 'src/index.ts', operation: 'modify', proposedContent: 'export const v = 2;\n' }],
    virtualFiles: vFiles
  });
  check(Boolean(propRes.proposal) && vFiles.get('src/index.ts')?.content === 'export const v = 1;\n', 'Proposal creation leaves original virtual file untouched');

  console.log(`\n======================================================`);
  console.log(`Master Audit Regression Summary: ${passed} passed, ${failed} failed.`);
  console.log(`======================================================`);

  if (failed > 0) {
    process.exit(1);
  }
}

void runMasterAuditRegressionTests();
